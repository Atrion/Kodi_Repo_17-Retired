__version__ = "1.3.5"
PACKAGE = "hachoir-parser"
WEBSITE = "http://bitbucket.org/haypo/hachoir/wiki/hachoir-parser"
LICENSE = 'GNU GPL v2'

